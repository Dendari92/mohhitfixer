--- @ --- @ --- @ --- @ --- @ --- @ ---- @ ---
M     M  OOOOO  H    H       H    H FFFFFF
MM   MM O     O H    H       H    H F
M M M M O     O H    H       H    H F
M  M  M O     O HHHHHH       HHHHHH FFFF
M     M O     O H    H       H    H F
M     M O     O H    H       H    H F
M     M  OOOOO  H    H ===== H    H F
--- @ --- @ --- @ --- @ --- @ --- @ --- @ ---

## What is it? ##
Medal of Honor HitFixer is a simple program which reduce bad hit registration in Medal of Honor. If you're experiencing any problems then you should try this program. It's not a total fix because you have to cosider a lot of factors, like your connection and the enimies one, but for sure it'll make the game more playable.

NOTE: PunkBuster won't ban you for using this program.

## How does it work? ##
It's very simple:
1) Run MOH and login;
2) Open the server browser and choose a server (better if more than one). Look at the ping in the server browser;
3) Close MOH and run MOH_HF;
4) Insert in the textbox your ping you saw in the server browser;
5) Check the "First Time" checkbox if you haven't use the app before or if you've deleted the "settings.ini" file (or the strings inside it); [no more needed in MOH_HF2]
6) Press the "Fix"/"Quick Fix" button and close the app;
7) Run MOH again and enter it the server you saw before or any servers with the same ping;

NOTE: you don't need to install nothing, just run the executable file.

## How can I undo the changes? ##

If you don't want to use anymore the fix click the "Default"/"Restore" button or delete the "settings.ini" file (you can find this file into "My Documents\EA Games\Medal of Honor\Multiplayer" folder).

## Can I customize the settings? ##

Bad Company 2 HitFixer 1 and 2 offer you an advanced tab which let you set every single thing which influences the hitboxes. For the description of every setting just leave the mouse over one of them for a short period of time and an hint will show up.

## Known issues ##
Q1. I receive an error "Unhandled exception has occured in your application..."
R1. It's a known issue and it usually occurs when: - The "settings.ini" file doesn't exist; - You haven't used the app before; - You have used the app before but you have deleted the "settings.ini" file; - You have used the app before but you have deleted the strings about the fix in the "settings.ini" file. Just ignore the message and try again the app after you've resolved one of the above problems.

[NOTE: this problem shouldn't be in MOH_HF2]

Q2. In the "settings.ini" file there are a lot of similar strings, what are they?
R1. They are the strings used to fix the hit registration problems. If you se a lot of them (more than 4-5 strings) then you haven't unchecked the "First Time" checkbox. This will nullify the fix. To resolve this problem you can: - Delete the "settings.ini" file; - Use the "Default" button until you receive the "Unhandled exception has occured in your application..." error.

[NOTE: this problem shouldn't be in MOH_HF2]

## Major changes from MOH_HF to MOH_HF2 ##

- Added the "Settings" tab which allow you to customize the program.
- Removed the "First Time" checkbox, making the program more "user-friendly".
- The two known issues shouldn't exist anymore.
- Every time the program is closed it'll create a new folder called "MOH_HF" into the "\EA Games\Medal of Honor\Multiplayer" folder in "My Documents". Inside that folder are stored the values and the settings of the program.

## Credits ##
Medal of Honor HitFixer was made by Andrea 'Dendari' Marini (in his free time, completely free and without any professional knowledge); based on BF2/2142 HitFixer by Guy.Buddy.Friend. from BF2S forum.